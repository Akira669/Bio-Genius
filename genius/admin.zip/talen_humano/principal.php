<?php
$user= $_SESSION['user'];

$permisos="";
 
echo "<div><center><b>TALENTO HUMANO</b></center></div>";

echo "<br><br><center>USUARIO: <b>".$user."</b><br> tiene permisos para: "."<br>".$permisos."</center>";

 echo "<br><center>DISCULPA LAS MOLESTIAS EN CONSTRUCCION</center>";
?>

