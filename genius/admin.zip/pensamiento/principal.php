<?php
$user= $_SESSION['user'];

$permisos="";
 
echo "<div><center><b>LOGISTICA</b></center></div>";

echo "<br><br><center>USUARIO: <b>".$user."</b><br> tiene permisos para: "."<br>".$permisos."</center>";

echo "<br><center> DISCULPE LAS MOLESTAS EN CONTRUCCION</center>";
?>

