<?php
$user= $_SESSION['user'];

$permisos="";
 
echo "<div><center><b>ADMINISTRACION</b></center></div>";

echo "<br><br><center>USUARIO: <b>".$user."</b><br> Tiene permisos para: "."<br>".$permisos."</center>";

echo "<br> <center>DISCULPE LAS MOLESTAS EN CONSTRUCCION</center>";
?>

