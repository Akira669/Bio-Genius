

<div class="panel panel-default">
  <div class="panel-footer text-right">
   <address> 
  Calle Sinaloa No.70, Barrio Tlatenco Teoloyucan, Estado de México C.P. 54770<br>
    <abbr title="Phone">P:</abbr> +52 (593) 914-8458/4702
  </address>
  </div>
</div>

